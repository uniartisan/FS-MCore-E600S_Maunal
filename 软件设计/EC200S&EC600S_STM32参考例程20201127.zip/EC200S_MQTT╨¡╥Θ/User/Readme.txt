[目录说明]
.
├── Applications 	驱动LTE模块需要用到的相关驱动库文件
├── Libraries 	    STM32F10x库文件
├── Project         MDK 工程
├── User	    	用户程序开发入口

[驱动库文件说明]
./Applications
├── gpio	GPIO驱动库，用于LTE模块PEN引脚控制，复位LTE模块
├── lte		LTE模块的驱动库，用于驱动LTE模块初始化，联网，数据交互相关操作
├── tim		定时器驱动
├── uart	串口驱动，串口1打印Debug信息，串口2与LTE模块通信
├── fat_core	串口驱动库文件，串口1打印Debug信息，串口2与LTE模块通信

[移植说明]
1.使用fat_core需要用到uart与定时器，所以使用前需要初始化好定时器跟与模组通信的uart
2.将"void fat_tim_proc(void)"函数放入定时器处理函数,"void fat_uart_recv_proc(unsigned char ch)"函数放入到串口中断处理函数
3."void reg_fat_uart_send_byte(void (*uart_send_byte)(unsigned char data))"函数是用来注册与模组所用的uart发送一个字节函数，用于fat_core处理相关uart发送数据
4.FAT_UART_RX_SIZE      --> 串口接收缓存大小
  FAT_UART_RX_IDLETIME  --> 串口接收中断空闲时间，在触发串口接收中断后达到该值时认为串口接收完成
  FAT_TIM_INTERVAL      --> 定时器间隔
