#ifndef __UART_H
#define __UART_H

#include "stm32f10x.h"
#include <stdio.h>

void uart1_init(void);
void uart2_init(void);
void uart2_send_byte(uint8_t data);
#endif
