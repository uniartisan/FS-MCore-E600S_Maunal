#ifndef __LTE_H
#define __LTE_H

#include "stm32f10x.h"


void module_MQTT(void);

#endif
