#ifndef __TIM_H
#define __TIM_H

#include "stm32f10x.h"

void tim2_init(int ms); //TIM2定时器初始化

#endif





